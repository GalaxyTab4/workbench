#ifndef SLANG_SLSH_H
#define SLANG_SLSH_H

extern int slsh_interactive (void);
extern int slsh_use_readline (char *, int, int);
extern int slsh_init_readline_intrinsics (void);
#endif				       /* SLANG_SLSH_H */
